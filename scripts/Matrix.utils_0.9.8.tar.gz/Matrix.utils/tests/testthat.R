library(testthat)
library(Matrix.utils)

test_check("Matrix.utils")
